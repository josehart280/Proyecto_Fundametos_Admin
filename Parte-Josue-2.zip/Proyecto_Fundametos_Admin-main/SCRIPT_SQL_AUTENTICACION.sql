-- ================================================================================
-- SCRIPT SQL - INTEGRACIONES NUEVAS
-- HU2: Cierre de sesión
-- HU3: Registro de acceso
-- ================================================================================

-- ================================================================================
-- PASO 1: COLUMNAS MÍNIMAS EN USUARIOS (requeridas por autenticación activa)
-- ================================================================================

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Usuarios' AND COLUMN_NAME = 'Fecha_Ultimo_Acceso')
  ALTER TABLE Usuarios ADD Fecha_Ultimo_Acceso DATETIME
ELSE
  PRINT 'Columna Fecha_Ultimo_Acceso ya existe'

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Usuarios' AND COLUMN_NAME = 'Intentos_Fallidos')
  ALTER TABLE Usuarios ADD Intentos_Fallidos INT CONSTRAINT DF_Usuarios_Intentos_Fallidos DEFAULT 0
ELSE
  PRINT 'Columna Intentos_Fallidos ya existe'

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Usuarios' AND COLUMN_NAME = 'Bloqueado')
  ALTER TABLE Usuarios ADD Bloqueado BIT CONSTRAINT DF_Usuarios_Bloqueado DEFAULT 0
ELSE
  PRINT 'Columna Bloqueado ya existe'

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Usuarios' AND COLUMN_NAME = 'Fecha_Bloqueo')
  ALTER TABLE Usuarios ADD Fecha_Bloqueo DATETIME
ELSE
  PRINT 'Columna Fecha_Bloqueo ya existe'

-- ================================================================================
-- PASO 2: TABLA DE BITÁCORA DE ACCESOS (HU3)
-- ================================================================================

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'Intentos_Acceso')
BEGIN
  CREATE TABLE Intentos_Acceso (
    id_Intento INT IDENTITY(1,1) PRIMARY KEY,
    id_Usuario INT NULL,
    Fecha_Intento DATETIME NOT NULL CONSTRAINT DF_Intentos_Acceso_Fecha DEFAULT GETDATE(),
    Resultado VARCHAR(20) NOT NULL,
    Razon_Fallo VARCHAR(500) NULL,
    IP_Cliente VARCHAR(50) NULL,
    CONSTRAINT FK_Intentos_Acceso_Usuarios FOREIGN KEY (id_Usuario) REFERENCES Usuarios(id_Usuario)
  )
  PRINT 'Tabla Intentos_Acceso creada'
END
ELSE
  PRINT 'Tabla Intentos_Acceso ya existe'

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_Intentos_Acceso' AND object_id = OBJECT_ID('Intentos_Acceso'))
  CREATE INDEX idx_Intentos_Acceso ON Intentos_Acceso(id_Usuario, Fecha_Intento)

-- Inmutabilidad de bitácora: no permitir UPDATE/DELETE
IF OBJECT_ID('tr_Intentos_Acceso_BloquearCambios', 'TR') IS NULL
BEGIN
  EXEC('
    CREATE TRIGGER tr_Intentos_Acceso_BloquearCambios
    ON Intentos_Acceso
    INSTEAD OF UPDATE, DELETE
    AS
    BEGIN
      SET NOCOUNT ON;
      RAISERROR(''Bitácora inmutable: no se permite modificar ni eliminar registros de Intentos_Acceso.'', 16, 1);
    END
  ')
  PRINT 'Trigger de inmutabilidad creado en Intentos_Acceso'
END
ELSE
  PRINT 'Trigger de inmutabilidad ya existe'

DENY UPDATE ON Intentos_Acceso TO PUBLIC
DENY DELETE ON Intentos_Acceso TO PUBLIC

-- ================================================================================
-- PASO 3: TABLA DE SESIONES (HU2)
-- ================================================================================

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'Sesiones')
BEGIN
  CREATE TABLE Sesiones (
    id_Sesion INT IDENTITY(1,1) PRIMARY KEY,
    id_Usuario INT NOT NULL,
    Token VARCHAR(500) NOT NULL UNIQUE,
    Fecha_Creacion DATETIME NOT NULL CONSTRAINT DF_Sesiones_Fecha_Creacion DEFAULT GETDATE(),
    Fecha_Expiracion DATETIME NULL,
    Activa BIT NOT NULL CONSTRAINT DF_Sesiones_Activa DEFAULT 1,
    CONSTRAINT FK_Sesiones_Usuarios FOREIGN KEY (id_Usuario) REFERENCES Usuarios(id_Usuario)
  )
  PRINT 'Tabla Sesiones creada'
END
ELSE
  PRINT 'Tabla Sesiones ya existe'

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_Sesiones_Activas' AND object_id = OBJECT_ID('Sesiones'))
  CREATE INDEX idx_Sesiones_Activas ON Sesiones(id_Usuario, Activa)

PRINT 'Script HU2 + HU3 aplicado correctamente'
